/*
 * world_builder C++ supervisor controller.
 */
#include <webots/Supervisor.hpp>
#include <webots/GPS.hpp>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>



#include <QFile>
#include <QXmlSimpleReader>
#include <QXmlInputSource>

#include "cblabhandler.h"

// Define the default maximum duration of the simulation in seconds
// This value can be overridden by the envoronment variable MAX_TIME
// Example: export MAX_TIME=60
double MAX_TIME_SECONDS = 300.0;

#define M_PI 3.14159265358979323846

struct cell_t
{
    int x, y;
};

// Get the e-puck node by DEF name (e.g., "EPUCK")
webots::Node *epuck_node;

#define PATHCUBESIZE (0.15)
#define ROBOTDIAM (0.071)

pid_t get_sibling_pid() {
    FILE *fp;
    char buffer[1024];
    char command[1024];
    pid_t sibling_pid=0;

    // Construct the command string:
    // pgrep -P [my_parent_pid] | grep -v [my_pid]
    snprintf(command, sizeof(command), 
             "pgrep -P %d | grep -v %d", getppid(), getpid());

    // Open a pipe to execute the command
    fp = popen(command, "r");
    if (fp == NULL) {
        perror("popen failed");
        return 0;
    }

    // Read the output line by line (each line contains one PID)
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        // Convert the string PID to an integer
        sibling_pid = atoi(buffer);
    }

    // Close the pipe
    pclose(fp);
    
    return sibling_pid;
}

bool is_pid_running(int pid) {
    if (pid <= 0) return false;
    // Sending signal 0 to a PID checks if the process is alive without killing it.
    // Returns 0 if process exists, -1 if it doesn't.
    return (kill(pid, 0) == 0);
}
struct cell_t getInitialCell(cbLab *lab)
{
    struct cell_t cell;

    cell.x = lab->Target(0)->Center().x / PATHCUBESIZE + 0.5;
    cell.y = lab->Target(0)->Center().y / PATHCUBESIZE + 0.5;
    std::cout << "initial cell: x=" << cell.x << " y=" << cell.y << std::endl;

    return cell;
}

void determine_lab_map_centered_on_robot_initial_pos(cbLab *lab)
{
    int cells_width  = int(lab->Width()  / PATHCUBESIZE + 0.5);
    int cells_height = int(lab->Height() / PATHCUBESIZE + 0.5);
    int lmap_width   = (cells_width - 2)  * 4 + 1;
    int lmap_height  = (cells_height - 2) * 4 + 1;
    char lmap[lmap_height][lmap_width];

    memset(lmap, ' ', sizeof(lmap));

    // debug
                  struct cell_t initCell = getInitialCell(lab);;

                  //fprintf(stderr,"initCell %d %d\n", initCell.x, initCell.y);

                  // find vertical lines
                  for(int cy = 1; cy < cells_height-1; cy++) {
                       for(int cx = 1; cx < cells_width; cx++) {
                            if(lab->isInside(cbPoint(cx*PATHCUBESIZE,cy*PATHCUBESIZE+0.5*PATHCUBESIZE))){
                                 //fprintf(stderr,"not reachable %d %d -> %d %d, lmap %d %d\n", cy, cx, cy, cx+1, 
                                 //         (cy-initCell.y)*2+lmap_height/2,(cx-initCell.x)*2+1+lmap_width/2);
                                 lmap[(cy-initCell.y)*2+lmap_height/2+1][(cx-initCell.x)*2+lmap_width/2] = '|';
                            }
                       } 
                  }

                  // find horizontal lines
                  for(int cy = 1; cy < cells_height; cy++) {
                       for(int cx = 1; cx < lmap_width-1; cx++) {
                            if(lab->isInside(cbPoint(cx*PATHCUBESIZE+0.5*PATHCUBESIZE,cy*PATHCUBESIZE))){
                                 lmap[(cy-initCell.y)*2+lmap_height/2][(cx-initCell.x)*2+1+lmap_width/2] = '-';
                            }
                       } 
                  }

                  //mark initial pos as I
                  lmap[lmap_height/2][lmap_width/2] = 'I';


                  FILE *fp=fopen("mapping.out","w");
                  if(fp==NULL) {
                       fprintf(stderr,"Could not create mapping file\n");
                  }
                  else {
                     for(int ly = lmap_height-1; ly>=0; ly--) {
                        for(int lx = 0; lx < lmap_width; lx++) {
                              fprintf(fp,"%c",lmap[ly][lx]);
                        } 
                        fprintf(fp,"\n");
                     }
                     fclose(fp);
                  }


}

int main(int argc, char **argv)
{
    // ---
    // 1. INITIALIZATION
    // ---
    webots::Supervisor *supervisor = new webots::Supervisor();
    int timeStep = (int)supervisor->getBasicTimeStep();

    // random offsets to avoid GPS informing on exact position in maze
    int offsetX = 0;
    int offsetY = 0;

    srand(time(0));
    offsetX = rand() % 40;
    offsetY = rand() % 19;

    // ---
    // 1a. GET MAXIMUM SIMULATION TIME
    // ---

    char *maxTimeEnv = getenv("MAX_TIME");
    if (maxTimeEnv != NULL)
    {
        char *pend;
        double maxTime = strtod(maxTimeEnv, &pend);
        if(*pend=='\0' && pend != maxTimeEnv) {
             MAX_TIME_SECONDS = maxTime;
        }
        else {
            fprintf(stderr,"Could not get max_time from MAX_TIME value (%s)\n", maxTimeEnv);
        }
    }
    std::cerr << "Maximum Simulation Time: " << MAX_TIME_SECONDS << " s\n";

    // ---
    // 2. GET SCENE TREE NODES
    // ---

    // Get the root node of the scene tree
    webots::Node *root_node = supervisor->getRoot();
    // Get the 'children' field of the root node, where we'll add new objects.
    webots::Field *children_field = root_node->getField("children");

    // ---
    // 3. DEFINE AND CREATE NEW OBJECTS
    // ---

    // Read lab file and create maze walls in webots
    char lab_filename[1024 * 8] = "C2-lab.xml";
    QXmlInputSource *source;

    QFile srcFile(lab_filename);

    if (!srcFile.exists())
    {
        std::cerr << "Could not open " << lab_filename << "\n";
        exit(0);
    }
    if ((source = new QXmlInputSource(&srcFile)) == 0)
    {
        std::cerr << "Fail sourcing lab file\n";
        exit(0);
    }

    cbLabHandler *labHandler = new cbLabHandler;
    labHandler->setChildrenField(children_field);
    labHandler->setOffsets(offsetX, offsetY);

    QXmlSimpleReader xmlParser;
    xmlParser.setContentHandler(labHandler);

    xmlParser.setErrorHandler(labHandler);

    if (!xmlParser.parse(source))
    {
        std::cerr << "Error parsing lab file\n";
        exit(0);
    }

    epuck_node = supervisor->getFromDef("EPUCK");
    if (epuck_node == NULL)
    {
        std::cerr << "No DEF EPUCK node found in the current world file\n";
        exit(0);
    }
    
    // Reposition robot to first target area of maze
    webots::Field *translationField = epuck_node->getField("translation");
    if (translationField) {
        // Define the new position (e.g., move to X=1.0, Y=2.0)
        double newTranslation[3] = {labHandler->getLab()->Target(0)->Center().x + offsetX * PATHCUBESIZE, 
                                    labHandler->getLab()->Target(0)->Center().y + offsetY * PATHCUBESIZE, 
                                    0.0}; 
        translationField->setSFVec3f(newTranslation);
        //std::cout << "E-puck repositioned." << std::endl;
    }

    // Get the PID of robot controller
    int robot_pid = get_sibling_pid();

    if (robot_pid == 0) {
        fprintf(stderr,"Could not get Robot Controller PID.\n");
        supervisor->simulationQuit(2);
    }    

    
    // Set custom data
    webots::Field *customDataField = epuck_node->getField("customData");
    
    if (!customDataField) {
        std::cerr << "Error: 'customData' field not found on EPUCK node." << std::endl;
        return 1;
    }
    
    char str_custom_data[4*1024];
    
    sprintf(str_custom_data,"FinalTime %.1f NTargets %d", MAX_TIME_SECONDS, labHandler->getLab()->nTargets());
    
    customDataField->setSFString(str_custom_data);

    determine_lab_map_centered_on_robot_initial_pos(labHandler->getLab());

    // ---
    // 4. MAIN LOOP (Optional)
    // ---

    // The main work is done, but the controller must keep running
    // for the simulation to continue.
    bool finished = false;
    float finalTime = 0.0;
    while (supervisor->step(timeStep) != -1)
    {
        std::string scoreText;

        // Get the current simulation time.
        double currentTime = supervisor->getTime();

        // Get Robot position inside maze (compensating offset)
        const double *position = epuck_node->getPosition();
        cbPoint robotPosInMaze(position[0] - offsetX * PATHCUBESIZE, position[1] - offsetY * PATHCUBESIZE) ;
        
        // Check if robot controller is alive
        if (robot_pid > 0 && !is_pid_running(robot_pid)) { 
            if(! finished) {
                printf("Robot controller finished at time %f.\n", currentTime);
                finalTime = currentTime;
            }

            finished = true;

            scoreText = "GAME OVER at "+ std::to_string(finalTime);

            //supervisor->simulationQuit(0); 
        }
        // Check if the simulation time has exceeded the maximum duration or robot not over the line
        else if (currentTime >= MAX_TIME_SECONDS
           || labHandler->getLab()->wallDistanceAboveHeight(robotPosInMaze, -1.0) > ROBOTDIAM*0.5) 
        {
            // The argument 0 indicates a successful exit.
            if (epuck_node) {
                epuck_node->remove();
                epuck_node = NULL;
            }
            scoreText = "GAME OVER";
        }
        else {
            scoreText = "";
        }

        // Display the label
        supervisor->setLabel(0, scoreText, 0.4, 0.01, 0.1, 0xFF0000, 0.0, "Arial");


    }

    delete supervisor;
    return 0;
}
